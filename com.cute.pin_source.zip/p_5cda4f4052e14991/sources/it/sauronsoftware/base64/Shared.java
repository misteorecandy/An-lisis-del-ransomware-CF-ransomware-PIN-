package it.sauronsoftware.base64;

/* JADX INFO: loaded from: classes.dex */
class Shared {
    static String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    static char pad = '=';

    Shared() {
    }
}
