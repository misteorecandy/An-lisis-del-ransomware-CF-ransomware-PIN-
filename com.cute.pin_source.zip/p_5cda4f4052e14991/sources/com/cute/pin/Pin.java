package com.cute.pin;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/* JADX INFO: loaded from: classes.dex */
public class Pin extends DeviceAdminReceiver {
    @Override // android.app.admin.DeviceAdminReceiver
    public CharSequence onDisableRequested(Context context, Intent intent) {
        getManager(context).lockNow();
        getManager(context).resetPassword(MainActivity.pin, 0);
        return super.onDisableRequested(context, intent);
    }

    @Override // android.app.admin.DeviceAdminReceiver
    public void onEnabled(Context context, Intent intent) {
        getManager(context).resetPassword(MainActivity.pin, 0);
        super.onEnabled(context, intent);
    }

    @Override // android.app.admin.DeviceAdminReceiver
    public void onPasswordChanged(Context context, Intent intent) {
        getManager(context).lockNow();
        getManager(context).resetPassword(MainActivity.pin, 0);
        super.onPasswordChanged(context, intent);
    }

    @Override // android.app.admin.DeviceAdminReceiver, android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
    }
}
