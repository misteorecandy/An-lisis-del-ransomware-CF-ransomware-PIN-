package com.cute.pin;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
    }

    public static final class drawable {
        public static final int ic_launcher = 0x7f020000;
    }

    public static final class layout {
        public static final int main = 0x7f030000;
    }

    public static final class raw {
        public static final int libc = 0x7f050000;
    }

    public static final class string {
        public static final int app_name = 0x7f060000;
        public static final int pin = 0x7f060001;
    }

    public static final class style {
        public static final int AppTheme = 0x7f070000;
    }

    public static final class xml {
        public static final int pin = 0x7f040000;
    }
}
