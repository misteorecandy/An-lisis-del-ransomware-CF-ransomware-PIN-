package Cute;

import java.security.Key;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

/* JADX INFO: loaded from: classes.dex */
public class AESUtils {
    private static final String ALGORITHM = "AES";
    private static final int CACHE_SIZE = 1024;
    private static final int KEY_SIZE = 128;

    public static byte[] decrypt(byte[] bArr, String str) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(toKey(Base64Utils.decode(str)).getEncoded(), ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(2, secretKeySpec);
        return cipher.doFinal(bArr);
    }

    public static String getSecretKey() throws Exception {
        return getSecretKey((String) null);
    }

    public static String getSecretKey(String str) throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
        keyGenerator.init(KEY_SIZE, (str == null || "".equals(str)) ? new SecureRandom() : new SecureRandom(str.getBytes()));
        return Base64Utils.encode(keyGenerator.generateKey().getEncoded());
    }

    private static Key toKey(byte[] bArr) throws Exception {
        return new SecretKeySpec(bArr, ALGORITHM);
    }
}
