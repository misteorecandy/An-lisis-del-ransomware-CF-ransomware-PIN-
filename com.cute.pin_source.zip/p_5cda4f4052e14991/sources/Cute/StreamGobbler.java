package Cute;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

/* JADX INFO: loaded from: classes.dex */
public class StreamGobbler extends Thread {
    InputStream is;
    OutputStream os;
    String type;

    StreamGobbler(InputStream inputStream, String str) {
        this(inputStream, str, (OutputStream) null);
    }

    StreamGobbler(InputStream inputStream, String str, OutputStream outputStream) {
        this.is = inputStream;
        this.type = str;
        this.os = outputStream;
    }

    private void close() {
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() throws Throwable {
        InputStreamReader inputStreamReader;
        Throwable th;
        PrintWriter printWriter;
        BufferedReader bufferedReader;
        InputStreamReader inputStreamReader2;
        IOException e;
        InputStreamReader inputStreamReader3 = (InputStreamReader) null;
        BufferedReader bufferedReader2 = (BufferedReader) null;
        PrintWriter printWriter2 = (PrintWriter) null;
        try {
            printWriter = this.os != null ? new PrintWriter(this.os) : printWriter2;
            try {
                inputStreamReader = new InputStreamReader(this.is);
                try {
                    bufferedReader = new BufferedReader(inputStreamReader);
                    try {
                        while (true) {
                            String line = bufferedReader.readLine();
                            if (line == null) {
                                break;
                            }
                            if (printWriter != null) {
                                printWriter.println(line);
                            }
                            System.out.println(new StringBuffer().append(new StringBuffer().append(this.type).append(">").toString()).append(line).toString());
                        }
                        if (printWriter != null) {
                            printWriter.flush();
                        }
                    } catch (IOException e2) {
                        e = e2;
                        bufferedReader2 = bufferedReader;
                        printWriter2 = printWriter;
                        inputStreamReader2 = inputStreamReader;
                        try {
                            e.printStackTrace();
                            inputStreamReader = inputStreamReader2;
                            printWriter = printWriter2;
                            bufferedReader = bufferedReader2;
                        } catch (Throwable th2) {
                            th = th2;
                            inputStreamReader = inputStreamReader2;
                            printWriter = printWriter2;
                            bufferedReader = bufferedReader2;
                            try {
                                printWriter.close();
                                bufferedReader.close();
                                inputStreamReader.close();
                            } catch (Exception e3) {
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        try {
                            printWriter.close();
                            bufferedReader.close();
                            inputStreamReader.close();
                        } catch (Exception e4) {
                        }
                        throw th;
                    }
                } catch (IOException e5) {
                    e = e5;
                    printWriter2 = printWriter;
                    inputStreamReader2 = inputStreamReader;
                } catch (Throwable th4) {
                    th = th4;
                    bufferedReader = bufferedReader2;
                }
            } catch (IOException e6) {
                printWriter2 = printWriter;
                inputStreamReader2 = inputStreamReader3;
                e = e6;
            } catch (Throwable th5) {
                inputStreamReader = inputStreamReader3;
                th = th5;
                bufferedReader = bufferedReader2;
            }
        } catch (IOException e7) {
            inputStreamReader2 = inputStreamReader3;
            e = e7;
        } catch (Throwable th6) {
            inputStreamReader = inputStreamReader3;
            th = th6;
            printWriter = printWriter2;
            bufferedReader = bufferedReader2;
        }
        try {
            printWriter.close();
            bufferedReader.close();
            inputStreamReader.close();
        } catch (Exception e8) {
        }
    }
}
